/* 
 * File:   main.cpp
 * Author: Joshua Jones
 * Created on January 7, 2020, 5:24 AM
 * Purpose: Assignment_1
 */

//System Libraries Here
#include <iostream>
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
   
    //Declare all Variables Here
    int num1, num2;
    int total;
    
    //Input or initialize values Here
    num1 = 50;
    num2 = 100;
    total = num1 + num2;//The total should be 150.
    
    //Process/Calculations Here
    cout<<"The total value is " <<total<<endl;
    
    //Output Located Here
    

    //Exit
    return 0;
}

