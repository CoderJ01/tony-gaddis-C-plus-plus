
/* 
 * File:   Assignment_1
 * Author: Joshua Jones
 * Created on January 9, 2020, 5:05 PM
 * Purpose: Homework
 */

#include <iostream>
using namespace std;
        
int main(int argc, char** argv) {
    
    cout<<"Joshua Jones \n123 Madison Avenue, Atlantis City, Bermuda State 12345 "
            "\n1-(123)-456-789 \nBiology major" <<endl;
   
    return 0;
}

