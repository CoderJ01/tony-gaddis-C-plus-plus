/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Assignment_1
 * Author: Joshua Jones
 * Created on January 8, 2020, 8:44 PM
 * Purpose: Homework
 */

#include <iostream>
using namespace std;

    //Global constants
    const int CNVPERC=100;

int main(int argc, char** argv) {
    
    cout<<"   *   "<<endl;
    cout<<"  ***  "<<endl;
    cout<<" *****  "<<endl; 
    cout<<"*******"<<endl; 
    cout<<" *****  "<<endl;
    cout<<"  ***  "<<endl;
    cout<<"   *   "<<endl;
   
    return 0;
}

